﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace Lesson16_09
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //string name = "Bogdan";
            //int age = 23;
            //float average = 10.8f;
            //Console.WriteLine("Name: "+ name + " Age: " + age); //конкатенація
            //Console.WriteLine("Name: {0} Age: {1} Average {2}", name,age,average);
            //Console.WriteLine($"Name {name} Age {age} Average {average}"); //інтерполяція

            Console.WriteLine("Enter Age: ");
            //int n = int.Parse(Console.ReadLine());
            int n = Convert.ToInt32(Console.ReadLine());

            Dog dog = new Dog("Eric", n);
            dog.ShowDog();
            Cat cat = new Cat();
            cat.ShowCat();

        }
    }
}
